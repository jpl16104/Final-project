import React from 'react';


class MyState extends React.Component {

    static my_score = 0;
    static my_count = 0;
};

export default MyState;