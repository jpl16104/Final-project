import React from 'react';


class HeaderData extends React.Component {

    static top_name = "Super quiz";
    static part_one = "part 1";

    getname() {
        return this.top_name;
    }
};

export default HeaderData;