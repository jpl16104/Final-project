//
// https://www.w3schools.com/REACT/react_css_styling.asp
//
const quizPageStyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Sans-Serif"
  };


  export default quizPageStyle;