import MyState from '../data/MyState';

var my_state = new MyState();

var my_score = 0;

export default my_state;
